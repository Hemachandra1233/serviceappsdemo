const { app } = require('@azure/functions');

app.http('ux-persons', {
    methods: ['GET','POST'],
    route: 'persons',
    headers: ['Content-Type=application/json'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Http function processed request for url "${request.url}"`);
        if (request.method == 'GET') {
            const result = await getPersons(request,context)
            return result
        }
        else if(request.method == 'POST') {
            const result = await postPersons(request,context)
            return result
        }
    }
});

async function postPersons(request, context) {
  const requestData = await request.json()
  //console.log(JSON.stringify(requestData))
  
  const webResponse = await fetch('https://httpbin.org/get')
  const webData     = await webResponse.json()
  console.log(JSON.stringify(webData))

  result = {
    status: 200,
    body: JSON.stringify({ user: `${requestData.name}`,fromip: `${webData.origin}`}),
    headers: {
        'Content-Type': 'application/json'
    }
  }
  return result
}

async function getPersons(request, context) {
    let name = request.query.get('name') || await request.text()
    name += ' hello'
    result = {
        status: 200,
        body: JSON.stringify({ message: name}),
        headers: {
            'Content-Type': 'application/json'
        }
      }
    return result
}

