const { app } = require('@azure/functions');

app.http('ux-spaces', {
    methods: ['GET'],
    route: 'spaces',
    headers: ['Content-Type=application/json'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Http function processed request for url "${request.url}"`);
        if (request.method == 'GET') {
            const result = await getSpaces(request,context)
            return result
        }
    }
});

async function getSpaces(request, context) {
    const email = request.query.get('email') || await request.text()
    const space = 'developer'
    result = {
        status: 200,
        body: JSON.stringify({ email: email, spaces: [space]}),
        headers: {
            'Content-Type': 'application/json'
        }
      }
    return result
}

